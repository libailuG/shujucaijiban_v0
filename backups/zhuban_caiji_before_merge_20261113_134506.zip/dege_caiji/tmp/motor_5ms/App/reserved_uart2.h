#ifndef RESERVED_UART2_H
#define RESERVED_UART2_H
#include <stdint.h>
#include "mcu_uart_protocol.h"

/* Board JP7 "reserved serial 2" is UART9, not USART2.
 * JP7: 1=GND, 2=RX/PD14, 3=TX/PD15, 4=3.3V. */
#define RESERVED_UART2_BAUD 921600UL
#define RESERVED_UART2_TX_PERIOD_US 50000UL /* 50ms = 20Hz. */
extern volatile td_mcu_frame_t g_uart2_tx_frame;
extern volatile td_mcu_frame_t g_uart2_rx_frame;
extern volatile uint32_t g_uart2_tx_count; /* Locally completed binary frames. */
extern volatile uint32_t g_uart2_rx_count;
extern volatile uint32_t g_uart2_last_rx;
extern volatile uint32_t g_uart2_error_count;
extern volatile uint32_t g_uart2_rx_frame_count;
extern volatile uint32_t g_uart2_rx_bad_tail_count;
extern volatile uint32_t g_uart2_rx_overflow_count;
extern volatile uint32_t g_uart2_rx_timestamp_us;
extern volatile uint32_t g_uart2_rx_valid; /* A complete frame has been received. */
/* Call after clock setup and imu_init() (TIM2 1MHz timebase). */
void reserved_uart2_init(void);
void reserved_uart2_poll(void);
/* Latest received frame only; returns 0 until the first valid frame. */
int reserved_uart2_get_rx(td_mcu_frame_t *out);
/* Main-loop API: takes a copy; fixed start/end flags are applied on encode. */
void reserved_uart2_set_tx(const td_mcu_frame_t *frame);
#endif
