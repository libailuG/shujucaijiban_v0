./objects/main.o: App\main.c Drivers\CMSIS\Device\stm32h7xx.h \
  Drivers\CMSIS\Device\stm32h723xx.h Drivers\CMSIS\Core\core_cm7.h \
  Drivers\CMSIS\Device\system_stm32h7xx.h App\imu.h App\imu_bus.h \
  App\battery.h App\reserved_uart2.h App\mcu_uart_protocol.h \
  App\control_mode1.h App\control_mode1_monitor.h App\reserved_uart1.h \
  App\motor_bus.h App\motor_protocol.h App\motor_debug_mode.h
