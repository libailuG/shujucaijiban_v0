./objects/imu_debug_mode.o: App\imu_debug_mode.c App\imu_debug_mode.h \
  App\mcu_uart_protocol.h App\imu.h
